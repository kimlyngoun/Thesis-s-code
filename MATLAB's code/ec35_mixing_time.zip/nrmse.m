function E = nrmse(F,A)
    %nrmse Normalized root mean square error between arrays
    %   This MATLAB function returns the normalized root mean square error
    %   (nrmse) in percentage (%) between the forecast (predicted) array F
    %   and the actual (observed) array A.
    
    E = 1/(mean(F)) * sqrt(mean((F - A).^2)) * 100;
end