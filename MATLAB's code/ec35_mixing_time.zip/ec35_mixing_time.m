close all; clc; clear;

%% Initialize data
%       edge    center  10 mn
ec_1 = [0.3384	0.3532	0.3578
        0.3433	0.3481	0.3578
        0.3433	0.3433	0.3578
        0.3481	0.3723	0.3578
        0.3481	0.3529	0.3578
        0.3384	0.3481	0.3578
        0.3384	0.3384	0.3578
        0.3384	0.3433	0.3578
        0.3481	0.3336	0.3578];

%       edge    center  10 mn
ec_3 = [0.5367	0.5173	0.5222
        0.5367	0.5173	0.5222
        0.5367	0.5173	0.5222
        0.5318	0.5173	0.527
        0.5367	0.5173	0.527
        0.5318	0.5173	0.527
        0.5318	0.5173	0.5222
        0.5318	0.5173	0.5222
        0.5318	0.5173	0.5222];

%       edge    center  10 mn
ec_5 = [0.8558	0.8364	0.8461
        0.8509	0.8413	0.8461
        0.8509	0.8413	0.8461
        0.8509	0.8413	0.8461
        0.8509	0.8413	0.8461
        0.8509	0.8364	0.8461
        0.8509	0.8413	0.8461
        0.8558	0.8364	0.8461
        0.8509	0.8413	0.8461];

%% Calculate errors and plot case mixing time of 1 minute
ec_edge = ec_1(:, 1);
ec_center = ec_1(:, 2);
ec_ref = ec_1(:, 3);
error_edge = nrmse(ec_ref, ec_edge);
error_center = nrmse(ec_ref, ec_center);

figure(1);
plot(1:9, ec_1, ".-");
title("Measured EC after 1 minute of mixing");
legend("Edge", "Center", "Center 10mn");
xlabel("Sample");
ylabel("EC [mS/cm]");
y_center = mean(ec_1(:,3));
y_upper = y_center*1.1;
y_lower = y_center*0.9;
ylim([y_lower y_upper]);
str = sprintf("\\epsilon_{edge} = %.2f%%", error_edge);
text(1.5, 0.335, str);
str = sprintf("\\epsilon_{center} = %.2f%%", error_center);
text(1.5, 0.33, str);

%% Calculate errors and plot case mixing time of 3 minute
ec_edge = ec_3(:, 1);
ec_center = ec_3(:, 2);
ec_ref = ec_3(:, 3);
error_edge = nrmse(ec_ref, ec_edge);
error_center = nrmse(ec_ref, ec_center);

figure(2);
plot(1:9, ec_3, ".-");
title("Measured EC after 3 minutes of mixing");
legend("Edge", "Center", "Center 10mn");
xlabel("Sample");
ylabel("EC [mS/cm]");
y_center = mean(ec_3(:,3));
y_upper = y_center*1.1;
y_lower = y_center*0.9;
ylim([y_lower y_upper]);
str = sprintf("\\epsilon_{edge} = %.2f%%", error_edge);
text(1.5, 0.49, str);
str = sprintf("\\epsilon_{center} = %.2f%%", error_center);
text(1.5, 0.482, str);

%% Calculate errors and plot case mixing time of 5 minute
ec_edge = ec_5(:, 1);
ec_center = ec_5(:, 2);
ec_ref = ec_5(:, 3);
error_edge = nrmse(ec_ref, ec_edge);
error_center = nrmse(ec_ref, ec_center);

figure(3);
plot(1:9, ec_5, ".-");
title("Measured EC after 5 minutes of mixing");
legend("Edge", "Center", "Center 10mn");
xlabel("Sample");
ylabel("EC [mS/cm]");
y_center = mean(ec_5(:,3));
y_upper = y_center*1.1;
y_lower = y_center*0.9;
ylim([y_lower y_upper]);
str = sprintf("\\epsilon_{edge} = %.2f%%", error_edge);
text(1.5, 0.8, str);
str = sprintf("\\epsilon_{center} = %.2f%%", error_center);
text(1.5, 0.785, str);
